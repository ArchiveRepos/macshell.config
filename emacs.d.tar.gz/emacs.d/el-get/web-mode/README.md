web-mode.el  [![Flattr this git repo](http://api.flattr.com/button/flattr-badge-large.png)](https://flattr.com/thing/1849746/web-mode-el)
=========

web-mode.el is an emacs major mode for editing **web templates** aka HTML files embedding parts (CSS/JavaScript) and blocks (pre rendered by client/server side engines).

web-mode.el is compatible with many template engines: PHP, JSP, ASP, Django, Twig, Jinja(2), ERB, FreeMarker, Velocity, Cheetah, Smarty, CTemplate, Mustache, Blade, ErlyDTL, Go Template, Dust.js, Google Closure (soy),  etc.

More infos on http://web-mode.org/

![ScreenShot](http://web-mode.org/web-mode.png?v=2)




