# -*- coding: utf-8 -*-

# Checking if the Pymacs helper loads.

import setup

def test_1():
    setup.start_python()
    setup.stop_python()
